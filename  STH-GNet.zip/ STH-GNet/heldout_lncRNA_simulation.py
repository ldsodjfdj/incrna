#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
heldout_lncRNA_simulation.py

Purpose
-------
Use a simulated lncRNA-disease association dataset to demonstrate a leakage-resistant
held-out lncRNA split experiment.

This script is intended as a runnable example for the reviewer-requested E1 experiment:
testing whether a model can generalize to lncRNAs that are completely unseen during training.

What this script does
---------------------
1. Simulates:
   - lncRNA feature matrix
   - disease feature matrix
   - lncRNA-disease association labels
2. Splits lncRNAs into train/test by entity:
   - test lncRNAs never appear in training
3. Trains a simple VAE-like predictor.
4. Reports AUC, AUPR, Accuracy, and F1-score.
5. Saves:
   - CSV result table
   - optional performance figure

Note
----
This is NOT the real MVCVAE implementation. It is a clean simulation template showing
how to perform held-out lncRNA evaluation. Replace the simulated features and labels
with your real MVCVAE inputs for the actual manuscript experiment.
"""

import argparse
import os
import random
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
    accuracy_score,
    f1_score,
)


# =========================
# Reproducibility
# =========================

def set_seed(seed: int = 42) -> None:
    """Set random seeds for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


# =========================
# Simulated data generation
# =========================

@dataclass
class SimulatedDataset:
    lnc_features: np.ndarray       # shape: [num_lncRNAs, lnc_feature_dim]
    disease_features: np.ndarray   # shape: [num_diseases, disease_feature_dim]
    labels: np.ndarray             # shape: [num_lncRNAs, num_diseases]


def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def generate_simulated_dataset(
    num_lncRNAs: int = 200,
    num_diseases: int = 40,
    lnc_feature_dim: int = 64,
    disease_feature_dim: int = 64,
    latent_dim: int = 16,
    positive_rate: float = 0.20,
    seed: int = 42,
) -> SimulatedDataset:
    """
    Generate a simulated lncRNA-disease association dataset.

    The simulation creates hidden latent factors for lncRNAs and diseases.
    Association labels are generated from latent compatibility scores plus noise.
    """
    rng = np.random.default_rng(seed)

    # Hidden biological factors
    z_lnc = rng.normal(0, 1, size=(num_lncRNAs, latent_dim))
    z_dis = rng.normal(0, 1, size=(num_diseases, latent_dim))

    # Observed features are noisy projections of hidden factors
    W_lnc = rng.normal(0, 1, size=(latent_dim, lnc_feature_dim))
    W_dis = rng.normal(0, 1, size=(latent_dim, disease_feature_dim))

    lnc_features = z_lnc @ W_lnc + rng.normal(0, 0.5, size=(num_lncRNAs, lnc_feature_dim))
    disease_features = z_dis @ W_dis + rng.normal(0, 0.5, size=(num_diseases, disease_feature_dim))

    # Standardize features
    lnc_features = (lnc_features - lnc_features.mean(axis=0)) / (lnc_features.std(axis=0) + 1e-8)
    disease_features = (disease_features - disease_features.mean(axis=0)) / (disease_features.std(axis=0) + 1e-8)

    # Association probability from latent compatibility
    score = (z_lnc @ z_dis.T) / np.sqrt(latent_dim)
    score += rng.normal(0, 0.8, size=score.shape)

    # Choose threshold to control positive rate
    threshold = np.quantile(score, 1.0 - positive_rate)
    labels = (score >= threshold).astype(np.float32)

    return SimulatedDataset(
        lnc_features=lnc_features.astype(np.float32),
        disease_features=disease_features.astype(np.float32),
        labels=labels.astype(np.float32),
    )


# =========================
# Held-out lncRNA split
# =========================

@dataclass
class PairDataset:
    x_pair: np.ndarray
    y_pair: np.ndarray
    lnc_indices: np.ndarray
    disease_indices: np.ndarray


def make_pair_dataset(
    dataset: SimulatedDataset,
    lnc_indices: np.ndarray,
) -> PairDataset:
    """
    Convert lncRNA-disease matrix into pair-level samples.

    Each sample is:
        [lncRNA feature, disease feature] -> association label
    """
    x_list = []
    y_list = []
    l_list = []
    d_list = []

    for i in lnc_indices:
        for j in range(dataset.labels.shape[1]):
            x = np.concatenate([dataset.lnc_features[i], dataset.disease_features[j]], axis=0)
            y = dataset.labels[i, j]
            x_list.append(x)
            y_list.append(y)
            l_list.append(i)
            d_list.append(j)

    return PairDataset(
        x_pair=np.asarray(x_list, dtype=np.float32),
        y_pair=np.asarray(y_list, dtype=np.float32),
        lnc_indices=np.asarray(l_list, dtype=np.int64),
        disease_indices=np.asarray(d_list, dtype=np.int64),
    )


def heldout_lncRNA_split(
    num_lncRNAs: int,
    test_ratio: float = 0.20,
    seed: int = 42,
):
    """
    Split by lncRNA entity.

    All pairs involving held-out test lncRNAs are placed in the test set.
    No test lncRNA appears in the training set.
    """
    rng = np.random.default_rng(seed)
    all_lnc = np.arange(num_lncRNAs)
    rng.shuffle(all_lnc)

    num_test = int(round(num_lncRNAs * test_ratio))
    test_lnc = np.sort(all_lnc[:num_test])
    train_lnc = np.sort(all_lnc[num_test:])

    return train_lnc, test_lnc


# =========================
# Model
# =========================

class PairVAEPredictor(nn.Module):
    """
    A simple VAE-like pair predictor.

    This is a compact simulation model:
    input pair feature -> latent distribution -> association probability
    """

    def __init__(self, input_dim: int, latent_dim: int = 32, hidden_dim: int = 128, dropout: float = 0.30):
        super().__init__()

        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.BatchNorm1d(hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

        self.fc_mu = nn.Linear(hidden_dim // 2, latent_dim)
        self.fc_logvar = nn.Linear(hidden_dim // 2, latent_dim)

        self.predictor = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, 1),
        )

    def encode(self, x):
        h = self.encoder(x)
        return self.fc_mu(h), self.fc_logvar(h)

    @staticmethod
    def reparameterize(mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        logits = self.predictor(z).squeeze(-1)
        return logits, mu, logvar


def loss_function(logits, labels, mu, logvar, beta: float = 0.001):
    """
    BCE + beta * KL divergence.
    """
    bce = nn.functional.binary_cross_entropy_with_logits(logits, labels)
    kld = -0.5 * torch.mean(1.0 + logvar - mu.pow(2) - logvar.exp())
    return bce + beta * kld


# =========================
# Train and evaluate
# =========================

def compute_metrics(y_true: np.ndarray, y_prob: np.ndarray, threshold: float = 0.5) -> dict:
    """Compute AUC, AUPR, Accuracy, and F1."""
    y_true = y_true.astype(int)
    y_pred = (y_prob >= threshold).astype(int)

    # AUC may fail if y_true contains only one class.
    try:
        auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        auc = np.nan

    try:
        aupr = average_precision_score(y_true, y_prob)
    except ValueError:
        aupr = np.nan

    acc = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred, zero_division=0)

    return {
        "AUC": auc,
        "AUPR": aupr,
        "Accuracy": acc,
        "F1-score": f1,
    }


def train_one_run(
    dataset: SimulatedDataset,
    test_ratio: float = 0.20,
    seed: int = 42,
    epochs: int = 80,
    batch_size: int = 128,
    learning_rate: float = 1e-3,
    latent_dim: int = 32,
    hidden_dim: int = 128,
    beta: float = 0.001,
    device: str = "cpu",
) -> dict:
    """Train and evaluate one held-out lncRNA split run."""
    set_seed(seed)

    train_lnc, test_lnc = heldout_lncRNA_split(
        num_lncRNAs=dataset.labels.shape[0],
        test_ratio=test_ratio,
        seed=seed,
    )

    train_pairs = make_pair_dataset(dataset, train_lnc)
    test_pairs = make_pair_dataset(dataset, test_lnc)

    train_x = torch.from_numpy(train_pairs.x_pair)
    train_y = torch.from_numpy(train_pairs.y_pair)

    test_x = torch.from_numpy(test_pairs.x_pair)
    test_y = torch.from_numpy(test_pairs.y_pair)

    train_loader = DataLoader(
        TensorDataset(train_x, train_y),
        batch_size=batch_size,
        shuffle=True,
        drop_last=False,
    )

    input_dim = train_pairs.x_pair.shape[1]
    model = PairVAEPredictor(
        input_dim=input_dim,
        latent_dim=latent_dim,
        hidden_dim=hidden_dim,
        dropout=0.30,
    ).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0

        for xb, yb in train_loader:
            xb = xb.to(device)
            yb = yb.to(device)

            optimizer.zero_grad()
            logits, mu, logvar = model(xb)
            loss = loss_function(logits, yb, mu, logvar, beta=beta)
            loss.backward()
            optimizer.step()

            total_loss += loss.item() * xb.size(0)

        if epoch % 20 == 0 or epoch == 1:
            avg_loss = total_loss / len(train_loader.dataset)
            print(f"[seed={seed}] Epoch {epoch:03d}/{epochs} | train loss = {avg_loss:.4f}")

    model.eval()
    with torch.no_grad():
        logits, _, _ = model(test_x.to(device))
        y_prob = torch.sigmoid(logits).cpu().numpy()

    y_true = test_y.numpy()
    metrics = compute_metrics(y_true, y_prob)

    metrics.update({
        "seed": seed,
        "num_train_lncRNAs": len(train_lnc),
        "num_test_lncRNAs": len(test_lnc),
        "num_train_pairs": len(train_pairs.y_pair),
        "num_test_pairs": len(test_pairs.y_pair),
        "positive_rate_train": float(train_pairs.y_pair.mean()),
        "positive_rate_test": float(test_pairs.y_pair.mean()),
    })

    return metrics


def summarize_results(results: list[dict]) -> pd.DataFrame:
    """Create one-row summary table with mean ± std."""
    df = pd.DataFrame(results)

    metric_cols = ["AUC", "AUPR", "Accuracy", "F1-score"]
    summary = {}

    for col in metric_cols:
        summary[col] = f"{df[col].mean():.4f} ± {df[col].std(ddof=1):.4f}"

    summary["num_runs"] = len(df)
    summary["protocol"] = "Held-out lncRNA split"

    return pd.DataFrame([summary])


def save_bar_plot(summary_df: pd.DataFrame, output_png: str) -> None:
    """Save a simple publication-style bar plot for the held-out lncRNA result."""
    import matplotlib.pyplot as plt

    row = summary_df.iloc[0]

    metrics = ["AUC", "AUPR", "Accuracy", "F1-score"]
    means = []
    stds = []

    for m in metrics:
        mean_str, std_str = row[m].split(" ± ")
        means.append(float(mean_str))
        stds.append(float(std_str))

    fig, ax = plt.subplots(figsize=(6.5, 4.2), dpi=300)

    x = np.arange(len(metrics))
    bars = ax.bar(x, means, yerr=stds, capsize=4)

    ax.set_ylim(0.0, 1.0)
    ax.set_ylabel("Score")
    ax.set_title("Held-out lncRNA Generalization Evaluation")
    ax.set_xticks(x)
    ax.set_xticklabels(metrics)
    ax.grid(axis="y", linestyle="--", alpha=0.35)

    for bar, mean in zip(bars, means):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.025,
            f"{mean:.4f}",
            ha="center",
            va="bottom",
            fontsize=9,
        )

    fig.tight_layout()
    fig.savefig(output_png, bbox_inches="tight")
    plt.close(fig)


# =========================
# Main
# =========================

def main():
    parser = argparse.ArgumentParser(
        description="Simulated held-out lncRNA split experiment for leakage-resistant generalization evaluation."
    )

    parser.add_argument("--num_lncRNAs", type=int, default=200)
    parser.add_argument("--num_diseases", type=int, default=40)
    parser.add_argument("--lnc_feature_dim", type=int, default=64)
    parser.add_argument("--disease_feature_dim", type=int, default=64)
    parser.add_argument("--data_latent_dim", type=int, default=16)
    parser.add_argument("--positive_rate", type=float, default=0.20)

    parser.add_argument("--test_ratio", type=float, default=0.20)
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--batch_size", type=int, default=128)
    parser.add_argument("--learning_rate", type=float, default=1e-3)
    parser.add_argument("--model_latent_dim", type=int, default=32)
    parser.add_argument("--hidden_dim", type=int, default=128)
    parser.add_argument("--beta", type=float, default=0.001)

    parser.add_argument("--seeds", type=int, nargs="+", default=[42, 43, 44, 45, 46])
    parser.add_argument("--output_dir", type=str, default="heldout_lncRNA_outputs")
    parser.add_argument("--save_plot", action="store_true")

    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")

    # Generate one dataset, then run multiple held-out splits with different seeds.
    dataset = generate_simulated_dataset(
        num_lncRNAs=args.num_lncRNAs,
        num_diseases=args.num_diseases,
        lnc_feature_dim=args.lnc_feature_dim,
        disease_feature_dim=args.disease_feature_dim,
        latent_dim=args.data_latent_dim,
        positive_rate=args.positive_rate,
        seed=2026,
    )

    results = []

    for seed in args.seeds:
        print("\n" + "=" * 70)
        print(f"Running held-out lncRNA split with seed = {seed}")
        print("=" * 70)

        metrics = train_one_run(
            dataset=dataset,
            test_ratio=args.test_ratio,
            seed=seed,
            epochs=args.epochs,
            batch_size=args.batch_size,
            learning_rate=args.learning_rate,
            latent_dim=args.model_latent_dim,
            hidden_dim=args.hidden_dim,
            beta=args.beta,
            device=device,
        )

        print(
            f"Result seed={seed}: "
            f"AUC={metrics['AUC']:.4f}, "
            f"AUPR={metrics['AUPR']:.4f}, "
            f"Accuracy={metrics['Accuracy']:.4f}, "
            f"F1={metrics['F1-score']:.4f}"
        )

        results.append(metrics)

    detailed_df = pd.DataFrame(results)
    summary_df = summarize_results(results)

    detailed_csv = output_dir / "heldout_lncRNA_detailed_results.csv"
    summary_csv = output_dir / "heldout_lncRNA_summary_results.csv"

    detailed_df.to_csv(detailed_csv, index=False)
    summary_df.to_csv(summary_csv, index=False)

    print("\n" + "=" * 70)
    print("Summary")
    print("=" * 70)
    print(summary_df.to_string(index=False))
    print(f"\nSaved detailed results to: {detailed_csv}")
    print(f"Saved summary results to:  {summary_csv}")

    if args.save_plot:
        output_png = output_dir / "heldout_lncRNA_performance.png"
        save_bar_plot(summary_df, str(output_png))
        print(f"Saved figure to: {output_png}")


if __name__ == "__main__":
    main()
