#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
renumber_tables_figures.py
===========================
对超大 Word 文档中的所有表格和图片按章节编号重新编号。

功能：
  - 按章节编号表格：第一章从「表1-1」开始，第二章从「表2-1」开始，以此类推
  - 按章节编号图片：第一章从「图1-1」开始，第二章从「图2-1」开始，以此类推
  - 识别并删除已有的旧编号，重新编号
  - 表名（标题行）：宋体五号加粗
  - 表格内容：宋体五号
  - 图题（图片标题）：宋体五号加粗
  - 内存友好，适合 2000+ 页大文档

用法：
  python renumber_tables_figures.py input.docx output.docx

依赖：
  pip install python-docx lxml
"""

import re
import sys
import copy
import argparse
import logging
from typing import Optional
from lxml import etree
from docx import Document
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

# ──────────────────────────────────────────────
# 日志配置
# ──────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger(__name__)

# ──────────────────────────────────────────────
# 常量
# ──────────────────────────────────────────────
SONG_FONT = "宋体"
FONT_SIZE_PT = 10.5          # 五号字 = 10.5pt（Word 内部单位为半磅，即 21）
FONT_SIZE_HALF_PT = 21       # python-docx 内部单位

# 匹配「表X-Y」或「表 X-Y」（章节号可以是多级，如1、1.1、二）
RE_TABLE_NUM = re.compile(
    r'^(表\s*)'                          # 「表」前缀
    r'([零一二三四五六七八九十百千万\d]+)'  # 章节号（中文或阿拉伯数字）
    r'[\-－–]'                           # 分隔符
    r'(\d+)'                             # 表序号
    r'(\s*)',                            # 尾部空格
    re.UNICODE
)

# 匹配「图X-Y」或「图 X-Y」
RE_FIGURE_NUM = re.compile(
    r'^(图\s*)'
    r'([零一二三四五六七八九十百千万\d]+)'
    r'[\-－–]'
    r'(\d+)'
    r'(\s*)',
    re.UNICODE
)

# 匹配章节标题（Heading 1 / 第X章 / 一、 等常见格式）
# 支持：Heading1 样式、「第X章」开头、「一、」「1.」「1 」开头
RE_CHAPTER = re.compile(
    r'^(?:'
    r'第\s*[零一二三四五六七八九十百千万\d]+\s*[章节篇]'  # 第一章
    r'|[零一二三四五六七八九十百千万]+[、．.]\s*\S'        # 一、总则
    r'|\d+\s*[、．.]\s*\S'                                # 1. 概述
    r')',
    re.UNICODE
)

# Heading 样式前缀
HEADING_STYLE_PREFIXES = ("heading 1", "标题 1", "heading1", "标题1")

# ──────────────────────────────────────────────
# 辅助：XML 操作
# ──────────────────────────────────────────────

def _w(tag: str) -> str:
    """返回带命名空间的标签，如 w:t → {http://...}t"""
    return qn(tag)


def para_text(para) -> str:
    """获取段落纯文本（忽略删除标记中的文字）"""
    parts = []
    for elem in para._p.iter():
        if elem.tag == qn("w:t"):
            # 跳过在 w:del 内的文字
            parent = elem.getparent()
            while parent is not None:
                if parent.tag == qn("w:del"):
                    break
                parent = parent.getparent()
            else:
                parts.append(elem.text or "")
    return "".join(parts)


def is_heading1(para) -> bool:
    """判断是否为一级标题"""
    style_name = (para.style.name or "").lower()
    if any(style_name.startswith(p) for p in HEADING_STYLE_PREFIXES):
        return True
    # 大纲级别 outlineLevel=0 也视为一级标题
    pPr = para._p.find(qn("w:pPr"))
    if pPr is not None:
        ol = pPr.find(qn("w:outlineLvl"))
        if ol is not None and ol.get(qn("w:val")) == "0":
            return True
    return False


def looks_like_chapter_heading(para) -> bool:
    """通过样式或文本内容判断是否为章节（一级）标题"""
    if is_heading1(para):
        return True
    text = para_text(para).strip()
    return bool(RE_CHAPTER.match(text))


# ──────────────────────────────────────────────
# 辅助：字体设置
# ──────────────────────────────────────────────

def _ensure_rpr(run_elem) -> etree._Element:
    """确保 <w:rPr> 存在并返回"""
    rPr = run_elem.find(qn("w:rPr"))
    if rPr is None:
        rPr = OxmlElement("w:rPr")
        run_elem.insert(0, rPr)
    return rPr


def _set_font_xml(rPr, font_name: str):
    """在 rPr XML 层设置中英文字体"""
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.insert(0, rFonts)
    rFonts.set(qn("w:eastAsia"), font_name)
    rFonts.set(qn("w:ascii"), font_name)
    rFonts.set(qn("w:hAnsi"), font_name)
    rFonts.set(qn("w:cs"), font_name)


def _set_size_xml(rPr, half_pt: int):
    """在 rPr XML 层设置字号（单位：半磅）"""
    for w_tag in ("w:sz", "w:szCs"):
        full_tag = qn(w_tag)
        elem = rPr.find(full_tag)
        if elem is None:
            elem = etree.SubElement(rPr, full_tag)
        elem.set(qn("w:val"), str(half_pt))


def _set_bold_xml(rPr, bold: bool):
    """在 rPr XML 层设置粗体"""
    b_tag = rPr.find(qn("w:b"))
    if bold:
        if b_tag is None:
            b_tag = OxmlElement("w:b")
            rPr.insert(0, b_tag)
    else:
        if b_tag is not None:
            rPr.remove(b_tag)
    # 同步 bCs
    bcs_tag = rPr.find(qn("w:bCs"))
    if bold:
        if bcs_tag is None:
            bcs_tag = OxmlElement("w:bCs")
            rPr.insert(0, bcs_tag)
    else:
        if bcs_tag is not None:
            rPr.remove(bcs_tag)


def apply_format_to_para(para, bold: bool):
    """
    将段落内所有 run 的字体设置为宋体五号（±加粗）。
    同时也设置段落级别的 rPr（pPr/rPr），确保新输入文字也继承格式。
    """
    # 段落级默认 rPr
    pPr = para._p.find(qn("w:pPr"))
    if pPr is None:
        pPr = OxmlElement("w:pPr")
        para._p.insert(0, pPr)
    p_rPr = pPr.find(qn("w:rPr"))
    if p_rPr is None:
        p_rPr = OxmlElement("w:rPr")
        pPr.append(p_rPr)
    _set_font_xml(p_rPr, SONG_FONT)
    _set_size_xml(p_rPr, FONT_SIZE_HALF_PT)
    _set_bold_xml(p_rPr, bold)

    # 各个 run
    for r in para._p.findall(".//" + qn("w:r")):
        # 跳过删除标记内的 run
        parent = r.getparent()
        in_del = False
        while parent is not None:
            if parent.tag == qn("w:del"):
                in_del = True
                break
            parent = parent.getparent()
        if in_del:
            continue
        rPr = _ensure_rpr(r)
        _set_font_xml(rPr, SONG_FONT)
        _set_size_xml(rPr, FONT_SIZE_HALF_PT)
        _set_bold_xml(rPr, bold)


def apply_format_to_table(table_obj):
    """将整个表格（所有单元格）内容设置为宋体五号不加粗"""
    for row in table_obj.rows:
        for cell in row.cells:
            for para in cell.paragraphs:
                apply_format_to_para(para, bold=False)


# ──────────────────────────────────────────────
# 辅助：段落编号文字操作
# ──────────────────────────────────────────────

def strip_old_number(para, pattern: re.Pattern) -> str:
    """
    从段落第一个 run 中剥离旧的编号前缀（如「表1-1 」），
    返回剥离后的纯文字（保留编号后的标题内容）。
    同时修改 XML 中的文本节点。
    """
    full_text = para_text(para).strip()
    m = pattern.match(full_text)
    if m:
        # 去掉整个匹配前缀，保留后面的标题
        remaining = full_text[m.end():]
    else:
        remaining = full_text
    return remaining


def rebuild_caption_runs(para, new_label: str, caption_text: str, bold: bool):
    """
    清空段落内所有 run，重建为：
      [新编号 run（宋体五号加粗）] [标题文字 run（宋体五号加粗/不加粗按 bold 参数）]
    表名：bold=True；图题：bold=True
    """
    p_elem = para._p

    # 保留 pPr，删除其余子元素（run / hyperlink / 书签等）
    children_to_remove = []
    for child in list(p_elem):
        tag = child.tag
        if tag in (qn("w:pPr"),):
            continue
        # 保留书签开始/结束，以防破坏文档结构
        if tag in (qn("w:bookmarkStart"), qn("w:bookmarkEnd")):
            continue
        children_to_remove.append(child)
    for child in children_to_remove:
        p_elem.remove(child)

    def make_run(text: str, is_bold: bool) -> etree._Element:
        r = OxmlElement("w:r")
        rPr = OxmlElement("w:rPr")
        _set_font_xml(rPr, SONG_FONT)
        _set_size_xml(rPr, FONT_SIZE_HALF_PT)
        _set_bold_xml(rPr, is_bold)
        r.append(rPr)
        t = OxmlElement("w:t")
        t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
        t.text = text
        r.append(t)
        return r

    # 编号 run（加粗）
    p_elem.append(make_run(new_label, True))
    # 标题文字 run
    if caption_text:
        p_elem.append(make_run(" " + caption_text, bold))


# ──────────────────────────────────────────────
# 核心逻辑：判断「表名行」和「图题行」
# ──────────────────────────────────────────────

def is_table_caption(para) -> bool:
    """
    判断段落是否为表名（表格上方或下方的标题行）。
    规则：
      1. 样式名含「表题」「表名」「caption」（不区分大小写）
      2. 文本以「表」开头（含已编号或未编号的）
      3. 样式名含 table caption
    """
    style = (para.style.name or "").lower()
    if any(k in style for k in ("表题", "表名", "caption", "table caption", "table title")):
        return True
    text = para_text(para).strip()
    if text.startswith("表") and len(text) > 1:
        return True
    # 已经是「表X-Y」格式
    if RE_TABLE_NUM.match(text):
        return True
    return False


def is_figure_caption(para) -> bool:
    """
    判断段落是否为图题（图片标题行）。
    规则：
      1. 样式名含「图题」「图名」「caption」「figure caption」
      2. 文本以「图」开头
      3. 已是「图X-Y」格式
    """
    style = (para.style.name or "").lower()
    if any(k in style for k in ("图题", "图名", "figure caption", "caption", "图 题")):
        return True
    text = para_text(para).strip()
    if text.startswith("图") and len(text) > 1:
        return True
    if RE_FIGURE_NUM.match(text):
        return True
    return False


def para_contains_image(para) -> bool:
    """判断段落中是否含有图片（drawing / pict）"""
    p = para._p
    return (
        p.find(".//" + qn("w:drawing")) is not None
        or p.find(".//" + qn("w:pict")) is not None
    )


# ──────────────────────────────────────────────
# 主处理函数
# ──────────────────────────────────────────────

def process_document(input_path: str, output_path: str):
    log.info(f"正在读取文档：{input_path}")
    doc = Document(input_path)
    log.info("文档读取完毕，开始处理…")

    # 收集文档主体中所有「块」（段落 + 表格），按顺序
    # doc.element.body 的直接子元素包含 w:p 和 w:tbl
    body = doc.element.body

    # 建立对象映射
    para_map = {p._p: p for p in doc.paragraphs}
    table_map = {t._tbl: t for t in doc.tables}

    # 当前章节号（1-based）
    chapter_num = 0
    # 各章节内表格/图片计数
    table_count = 0
    figure_count = 0

    # 统计
    total_tables_renamed = 0
    total_figures_renamed = 0

    processed_elements = 0
    total_elements = len(list(body))

    log.info(f"文档共 {total_elements} 个顶层元素（段落+表格），开始逐一处理…")

    i = 0
    children = list(body)  # 快照，避免迭代中修改

    for elem in children:
        processed_elements += 1
        if processed_elements % 2000 == 0:
            log.info(
                f"  进度：{processed_elements}/{total_elements} "
                f"（第{chapter_num}章，已重命名表格{total_tables_renamed}个，"
                f"图片{total_figures_renamed}个）"
            )

        tag = elem.tag

        # ── 段落 ──────────────────────────────────
        if tag == qn("w:p"):
            para = para_map.get(elem)
            if para is None:
                # 嵌套段落（表格内），跳过此处理（表格内部另行处理）
                continue

            # 判断是否为一级章节标题
            if looks_like_chapter_heading(para):
                chapter_num += 1
                table_count = 0
                figure_count = 0
                log.debug(f"  检测到第{chapter_num}章")
                continue

            # 跳过空段落
            text = para_text(para).strip()
            if not text and not para_contains_image(para):
                continue

            # ── 表名段落 ──────────────────────────
            if is_table_caption(para):
                if chapter_num == 0:
                    chapter_num = 1  # 章节标题前的表格归入第1章
                table_count += 1
                new_label = f"表{chapter_num}-{table_count}"
                old_text = strip_old_number(para, RE_TABLE_NUM)
                rebuild_caption_runs(para, new_label, old_text, bold=True)
                apply_format_to_para(para, bold=True)
                total_tables_renamed += 1
                log.debug(f"  {new_label}：{old_text[:30]}")
                continue

            # ── 图题段落 ──────────────────────────
            if is_figure_caption(para):
                if chapter_num == 0:
                    chapter_num = 1
                figure_count += 1
                new_label = f"图{chapter_num}-{figure_count}"
                old_text = strip_old_number(para, RE_FIGURE_NUM)
                rebuild_caption_runs(para, new_label, old_text, bold=True)
                apply_format_to_para(para, bold=True)
                total_figures_renamed += 1
                log.debug(f"  {new_label}：{old_text[:30]}")
                continue

            # ── 含图片但无图题的段落（图片直接嵌在段落里）──
            # 此处不自动新增图题，仅格式化段落字体（如用户需要可取消注释）
            # if para_contains_image(para):
            #     pass

        # ── 表格 ──────────────────────────────────
        elif tag == qn("w:tbl"):
            tbl = table_map.get(elem)
            if tbl is None:
                continue
            # 格式化表格内容（宋体五号不加粗）
            apply_format_to_table(tbl)

    log.info("=" * 60)
    log.info(f"处理完成！")
    log.info(f"  重命名表格数：{total_tables_renamed}")
    log.info(f"  重命名图片数：{total_figures_renamed}")
    log.info(f"  共处理章节数：{chapter_num}")
    log.info(f"正在保存到：{output_path}")
    doc.save(output_path)
    log.info("保存完成！")


# ──────────────────────────────────────────────
# 命令行入口
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="对 Word 文档按章节自动编号表格和图片"
    )
    parser.add_argument("input", help="输入 .docx 文件路径")
    parser.add_argument("output", help="输出 .docx 文件路径")
    parser.add_argument(
        "--debug", action="store_true", help="显示调试日志（每个表/图的重命名详情）"
    )
    args = parser.parse_args()

    if args.debug:
        log.setLevel(logging.DEBUG)

    process_document(args.input, args.output)


if __name__ == "__main__":
    main()